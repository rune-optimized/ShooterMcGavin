lambeq.reader
=============

.. automodule:: lambeq.reader
   :members:
   :undoc-members:
   :show-inheritance:
