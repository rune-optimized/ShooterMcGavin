lambeq.pregroups
================

.. automodule:: lambeq.pregroups
   :members:
   :undoc-members:
   :show-inheritance:
