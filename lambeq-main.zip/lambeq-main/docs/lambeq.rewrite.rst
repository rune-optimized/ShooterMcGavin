lambeq.rewrite
==============

.. automodule:: lambeq.rewrite
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: PLACEHOLDER_WORD
