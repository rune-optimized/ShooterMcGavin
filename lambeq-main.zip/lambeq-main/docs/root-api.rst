lambeq package
==============

.. automodule:: lambeq
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :exclude-members: ccg_type_regex, id_regex, escaped_words, tree_regex, verbose, SMOOTHING, PLACEHOLDER_WORD
