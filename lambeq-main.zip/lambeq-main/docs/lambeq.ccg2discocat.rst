lambeq.ccg2discocat
===================

.. automodule:: lambeq.ccg2discocat
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: ccg_type_regex, id_regex, escaped_words, tree_regex, verbose
