lambeq.ansatz
=============

.. automodule:: lambeq.ansatz
   :members:
   :undoc-members:
   :show-inheritance:
