lambeq.training
===============

.. automodule:: lambeq.training
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: SMOOTHING
