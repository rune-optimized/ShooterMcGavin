#!/usr/bin/env sh
cat <<'EOF'
This install script is no longer needed and has been removed in version 0.2.0.
To install lambeq, run: `pip install lambeq`
To install lambeq with extra dependencies, run: `pip install lambeq[extras]`
To install lambeq with depccg, run: `pip install lambeq depccg`
EOF
